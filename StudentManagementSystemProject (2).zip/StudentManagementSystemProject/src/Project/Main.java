package Project;

public class Main {
    public static void main(String[] args) {
        SplashScreen.showSplashAndLaunch();
    }
}